About
=====

This subproject describes parser specific objects:

* ``quoted_string`` provides rule to handle quotes in strings;
* ``variant_decorator`` provides recursive variant with built-in ``as`` method.
* ``load_from_string`` is already implemented, this function is needed to construct object from parser with ease.

Requirements
============

Pass all tests.
